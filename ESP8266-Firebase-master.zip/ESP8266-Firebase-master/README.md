# ESP8266-Firebase
ESP8266 WiFi Module Sent Sensor Data to Firebase Realtime Database

Hardware
1.ESP8266 WiFi Module ( We use ESP8266 12E )
2.Temperature and Humidity Sensor DHTxx ( we use DHT22 or AM2302 )
3.OLED Display for Option

Library
Firebase Arduino Library
WiFi Connector
DHT Sensor
Adafriut GFX ( OLED Display ) 

more info
http://microcontrollerkits.blogspot.com/2016/12/esp8266-firebase.html

